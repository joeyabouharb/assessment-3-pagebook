const argon2 = require('argon2');
const pagesDBClient = require('./DatabaseClient');

/**
 *
 * Handles CRUD opperations for Accounts in specified database,
 * Register, Login, Logout, Delete and update details
 *
 * @param {string} db
 */
const AccountRepository = () => {
  const client = pagesDBClient();

  /**
   * create a new account
   * @param {Account} account
   */
  const register = (account) => {
    const sql = `
    INSERT INTO Accounts(accountID, userName, password, email, isVerified, isTwoFactor, token)
      VALUES($accountID, $userName, $password, $email, $isVerified, $isTwoFactor, $token)
    `;
    const result = client.modify(sql, account);
    if (result.error) {
      const { code } = result.error;
      return code === 'SQLITE_CONSTRAINT_UNIQUE'
        ? { error: 'user already exists', status: 400 }
        : { error: 'an unspecified error occured.', status: 500 };
    }
    return result;
  };
  const registerMany = (accounts) => {
    const sql = `
    INSERT INTO Accounts(accountID, userName, password, email, isVerified, isTwoFactor, token)
      VALUES($accountID, $userName, $password, $email, $isVerified, $isTwoFactor, $token)
    `;
    const result = client.batchModify(sql, accounts);
    return result;
  };

  /**
   * Login user from user Name credentials and verify password
   * @param {Login} param0
   */
  const login = async ({ userName, password }) => {
    const sql = `
    SELECT password, userName, token, accountID
    FROM Accounts
    where userName == $userName
    `;
    const user = client.getOne(sql, { userName });
    if (user.error) {
      return { error: 'credentials were not valid!', status: 401 };
    }
    const { password: hash, ...rest } = user;
    const success = await argon2.verify(hash, password);
    if (!success) {
      return { error: 'Credentials were not valid!', status: 401 };
    }
    return rest;
  };
  const checkIfUserExists = (accountID) => {
    const sql = `
    SELECT userName, email
    FROM Accounts
    WHERE accountID == $accountID
    `;
    const account = client.getOne(sql, { accountID });
    if (account.error) {
      return { error: account.status, status: 401 };
    }
    return account;
  };

  const deleteAccount = (accountID) => {
    const sql = `
    DELETE
    FROM Accounts
    WHERE accountID == $accountID
    `;
    const result = client.modify(sql, { accountID });
    if (result.error) {
      return { error: result, status: result.status };
    }
    return result;
  };

  const updateAccountDetails = (account) => {
    const sql = `
    UPDATE Accounts
    SET email = $email,
    userName = $userName
    WHERE token == $token
    `;
    const result = client.modify(sql, account);
    if (result.error) {
      return { error: result.error, status: result.status };
    }
    console.log(result);
    return result;
  };

  const updateAccountPassword = (details) => {
    console.log(details);
    const sql = `
    UPDATE Accounts
    SET password = $password
    WHERE token == $token
    `;
    const result = client.modify(sql, details);
    if (result.error) {
      return { error: result.error, status: 400 };
    }
    return result;
  };

  return {
    register,
    login,
    checkIfUserExists,
    deleteAccount,
    updateAccountDetails,
    updateAccountPassword,
    registerMany,
    close: () => { client.close(); },
  };
};

module.exports = Object.freeze(AccountRepository);
