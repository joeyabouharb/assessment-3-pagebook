const { Router } = require('express');
const PageController = require('../controllers/pages');
const { requiresValidation } = require('../utils/validators');
const Page = require('../models/page');
const GuestController = require('../controllers/guest');

const pageRouter = Router();

pageRouter.post('/', requiresValidation(Page), PageController.createPage);
pageRouter.patch('/:pageID', requiresValidation(Page), PageController.updatePage);
pageRouter.delete('/:pageID', PageController.deletePage);
pageRouter.get('/', PageController.getManagedPages);
pageRouter.get('/:pageID', GuestController.getPageDetails);
module.exports = Object.freeze(pageRouter);
