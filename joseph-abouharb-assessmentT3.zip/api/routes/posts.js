const { Router } = require('express');
const postController = require('../controllers/post');
const Posts = require('../models/posts');
const EditPosts = require('../models/editPost');
const { requiresValidation } = require('../utils/validators');

const postRouter = Router();

postRouter.post('/', requiresValidation(Posts), postController.create);
postRouter.get('/', postController.getPosts);
postRouter.patch('/:postID', requiresValidation(EditPosts), postController.update);
postRouter.delete('/:postID', postController.destroy);
postRouter.get('/analysis', postController.getEstimatedMaxLiked);
module.exports = Object.freeze(postRouter);
